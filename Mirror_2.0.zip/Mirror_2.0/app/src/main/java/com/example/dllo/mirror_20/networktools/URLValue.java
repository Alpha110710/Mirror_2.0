package com.example.dllo.mirror_20.networktools;

/**
 * Created by dllo on 16/6/22.
 */
public final class URLValue {

    public static final String VERIFICATION = "http://api.mirroreye.cn/index.php/user/send_code";//注册页验证码

    public static final String REGISTER="http://api.mirroreye.cn/index.php/user/reg";//注册

    public static final String LOGIN="http://api.mirroreye.cn/index.php/user/login";//登录

    public static final String JOINBUCAR="http://api.mirroreye.cn/index.php/order/join_shopping_cart";//加入购物车



}

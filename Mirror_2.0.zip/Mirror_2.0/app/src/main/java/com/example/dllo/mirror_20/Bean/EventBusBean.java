package com.example.dllo.mirror_20.Bean;

/**
 * Created by dllo on 16/6/24.
 */
public class EventBusBean {
    public String text;

    public EventBusBean(String text) {
        this.text = text;
    }
}

package com.example.dllo.mirror_20.sql;

/**
 * Created by dllo on 16/6/25.
 */
public class SQLValues {

    public static final String SQL_BUY_CAR_NAME = "buyCar.db";
    public  static  final  String TABLE_NAME = "buycart";
    public static final String GOOD_ID="goods_id";
    public static final String GOODS_NAME = "goods_name";
    public static final String MODEL = "model";
    public static final String GOODS_IMG = "goods_img";
    public static final String GOODS_PRICE = "goods_price";
    public static final String PRODUCT_AREA = "product_area";
}

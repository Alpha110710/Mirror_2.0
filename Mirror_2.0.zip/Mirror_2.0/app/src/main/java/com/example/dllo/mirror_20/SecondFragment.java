package com.example.dllo.mirror_20;

import android.view.View;

import com.example.dllo.mirror_20.base.BaseFragment;

/**
 * Created by dllo on 16/6/21.
 */
public class SecondFragment extends BaseFragment {

    @Override
    public int setLayout() {
        return R.layout.fragment_second;
    }

    @Override
    public void initView(View view) {

    }


    @Override
    public void initData() {

    }
}

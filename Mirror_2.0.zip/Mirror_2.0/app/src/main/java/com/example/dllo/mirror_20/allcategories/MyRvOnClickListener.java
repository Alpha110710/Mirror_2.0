package com.example.dllo.mirror_20.allcategories;

/**
 * Created by dllo on 16/6/22.
 */
public interface MyRvOnClickListener {
    void onClick(int position);
}

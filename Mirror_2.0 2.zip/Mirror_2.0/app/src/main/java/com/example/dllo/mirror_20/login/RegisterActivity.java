package com.example.dllo.mirror_20.login;


import com.example.dllo.mirror_20.R;
import com.example.dllo.mirror_20.base.BaseActivity;

/**
 * Created by dllo on 16/6/20.
 */
public class RegisterActivity extends BaseActivity {
    @Override
    public void initActivity() {
        setContentView(R.layout.activity_register);
    }
}
